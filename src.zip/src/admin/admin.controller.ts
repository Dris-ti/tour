import { Controller, Post, Body, Get, Res, Req } from '@nestjs/common';
import { AdminService } from './admin.service';

@Controller('admin')
export class AdminController {
    constructor(private readonly AdminService: AdminService) {}

    @Get("/passwordHasing")
    passwordHasing(@Body() data)
    {
        return this.AdminService.passwordHasing(data);
    }

    @Post("/login")
    login(@Body() data, @Res() res)
    {
        return this.AdminService.login(data, res);
    }

    @Post("/logout")
    logout(@Req() req, @Res() res)
    {
        return this.AdminService.logout(req, res);
    }

    @Post("/editAdminProfile")
    editAdminProfile(@Body() data, @Req() req, @Res() res)
    {
        return this.AdminService.editAdminProfile(data, req, res);
    }

    @Post("/changePassword")
    changePassword(@Body() data, @Req() req, @Res() res)
    {
        return this.AdminService.changePassword(data, req, res);
    }

    @Post("/requestChangePassword")
    requestChangePassword(@Req() req, @Res() res)
    {
        return this.AdminService.requestChangePassword(req, res);
    }

    @Post("/forgetPassword")
    forgetPassword(@Body() data)
    {
        return this.AdminService.forgetPassword(data);
    }

    


}
